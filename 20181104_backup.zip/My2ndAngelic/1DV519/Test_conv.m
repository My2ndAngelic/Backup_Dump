format longg;
clear;
clc;
x = 100001;
result = [];
tol = 1*10^(-8); % Tolerance
it = 0; % Iteration
xnplus1 = x; 
storage = [];
aa = [];
breakflag = 0;
% Remove in 500 iteration
forwarderror = [];
convergentrate = [];


    % Calculate
    while abs(xnplus1^2 - x) > tol
        it = it+1;
        xn = xnplus1; 
        xnplus1 = 0.5*(xn +(x / xn));
        storage(it) = xnplus1;

        forwarderror(it) = abs(xnplus1-sqrt(x));
        
        convergentrate(it) = abs((xnplus1 - sqrt(x))/(((xn - sqrt(x)))^2));
        
    end
    
% Output
result = [x,forwarderror(size(forwarderror,2)),convergentrate(size(forwarderror,2)),it,xnplus1,log10(forwarderror(size(forwarderror,2))),sqrt(x)]
export = [storage',forwarderror',convergentrate']
