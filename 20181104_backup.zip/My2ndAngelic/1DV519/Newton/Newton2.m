%function [xnplus1, it] = newton	
clear;
clc;
format shortG;
result = [];

% Calculation
for x = 2:1:500
    tol = 1*10^(-15); % Tolerance
    it = 0; % Iteration
    xnplus1 = x; 
    storage = [];
    aa = [];
    breakflag = 0;

    % Calculate
    while abs(xnplus1^2 - x) > tol
        it = it+1;
        xn = xnplus1; 
        xnplus1 = 0.5*(xn +(x / xn));
        storage(it) = xnplus1;

        aa(it) = abs(xnplus1^2 - x);

        if it > 1
            if aa(it) == aa(it - 1)
                breakflag = 1;
                break;
            end
        end
    end

    % Error estimation
    errorestimate = [];
    
    for k = 1:1:it
        errorestimate(k) = abs(storage(it) - storage(k));
    end
    
    if errorestimate(size(errorestimate,2)-1) == 0
        errorestimate(size(errorestimate,2)-1) = [];
    end
    
    % Output
    storage;    

    it = it - 1;
    finalerror = xnplus1 - sqrt(x);
    sprintf('%.30e',xnplus1);
    
    % Result | Input | Breakflag | Final error | Iteration | xnplus1 | Error (log scale) | Error (absolute)
    result = [result;x,breakflag,finalerror,it,xnplus1,log10(errorestimate(size(errorestimate,2)-1)),errorestimate(size(errorestimate,2)-1)];
end

% Test

% Result not reached
result2 = [result(1,:)];
for i=1:1:size(result,1)
   if result(i,3) ~= 0
     result2 = [result2;result(i,:)];
   end
end

% Flag tripped
result3 = [result(1,:)];
for i=1:1:size(result,1)
    if result(i,2) ~= 0
        result3 = [result3;result(i,:)];
    end
end

% Flag tripped and accurate result
result4 = [result(1,:)];
for i=1:1:size(result,1)
    if result(i,2) ~= 0 && result(i,3) == 0
        result4 = [result4;result(i,:)];
    end
end

% Flag tripped and inaccurate result
result5 = [result(1,:)];
for i=1:1:size(result,1)
    if result(i,2) ~= 0 && result(i,3)~= 0
        result5 = [result5;result(i,:)];
    end
end

% Inaccurate and prime
result6 = [result(1,:)];
for i=1:1:size(result,1)
    if isprime(result(i,1)) == 1 && result(i,3) ~= 0
        result6 = [result6;result(i,:)];
    end
end

%Accurate and prime
result7 = [result(1,:)];
for i=1:1:size(result,1)
    if isprime(result(i,1)) == 1 && result(i,3) == 0
        result7 = [result7;result(i,:)];
    end
end


hold on;
 scatter(result(:,1),result(:,3),'xk') %change the 2nd element
% scatter(result2(:,1),abs(result2(:,5)),'xb')
 scatter(result3(:,1),result3(:,3),'xm')
% scatter(result4(:,1),abs(result4(:,3)),'xm')
% scatter(result5(:,1),abs(result5(:,3)),'xr')
% scatter(result6(:,1),abs(result6(:,3)),'xc')
% scatter(result7(:,1),abs(result7(:,3)),'xc')


% hold off;
% plot(result(:,1),abs(result(:,4)),'-c')

% size(result(:,3))
% size(result2(:,3))
% size(result4(:,3))

set(gca,'fontsize',20)

result

size(result3(:,2)==1)
