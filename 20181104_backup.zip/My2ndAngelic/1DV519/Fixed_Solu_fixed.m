%function [xnplus1, it] = newton	
clear;
clc;
format shortG;
result = [];

% Calculation
for x = 2:1:500
    tol = 1*10^(-8); % Tolerance
    it = 0; % Iteration
    xnplus1 = x; 
    storage = [];
    aa = [];
    breakflag = 0;
%     forwarderror = [];
%     convergentrate = [];


    % Calculate
    storage(1) = xnplus1;
    while abs(xnplus1^2 - x) > tol
        it = it+1;
        xn = xnplus1; 
        xnplus1 = 0.5*(xn +(x / xn));
        storage(it+1) = xnplus1;

        aa(it) = abs(xnplus1^2 - x);
        forwarderror = xnplus1-sqrt(x);
        
        if (xnplus1 - sqrt(x)) ~= 0
            convergentrate = (xnplus1 - sqrt(x))/(((xn - sqrt(x)))^2);
        end
        
    end
    
    % Output
    storage;    

    it = it - 1;
    
    result = [result;x,forwarderror(size(forwarderror,2)),convergentrate(size(forwarderror,2)),it,xnplus1,log10(forwarderror(size(forwarderror,2))),sqrt(x)];
end

% Test
hold on;
plot(result(:,1),abs(result(:,7)),'xk')
set(gca,'fontsize',20);

result